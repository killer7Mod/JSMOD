package com.wmods.jsmod.skiphosts;
import android.os.*;
import java.util.regex.*;
import android.util.*;
import com.wmods.jsmod.utils.*;
import java.net.*;

public class ahref extends AsyncTask<String,Void,Void>
{

	@Override
	protected Void doInBackground(String[] p1)
	{

		try
		{
			ModUtils.showToast("Desprotegendo...");
			String url = p1[0];
			Matcher m = Pattern.compile("https?://ahref\\.co/(?:.+?)/(.+)").matcher(url);
			if (!m.find())
			{
				url = getLink(p1[0]);
				m = Pattern.compile("/(?:.+?)/(.+)").matcher(url);
			}
			//ModUtils.showToast(url);
			if (m.find())
			{
				String data = decode(m.group(1));
				Matcher m2 = Pattern.compile("\\{sht\\-io\\}(.+?)\\{sht\\-io\\}").matcher(data);
				if (m2.find() && ModUtils.isURL(m2.group(1)))
				{
					ModUtils.openURL(m2.group(1), false);
				}
			}
		}
		catch (Exception e)
		{
			ModUtils.showToast(e.toString());
		}
		return null;
	}

	private String decode(String data)
	{
		try
		{
			return new String(Base64.decode(data, 0));
		}
		catch (Exception e)
		{}
		return null;
	}

	private String getLink(String url) throws Exception
	{
		URL mUrl = new URL(url);
		HttpURLConnection hc = (HttpURLConnection)mUrl.openConnection();
		hc.setInstanceFollowRedirects(false);
		return hc.getHeaderField("Location");
	}


}
