package com.wmods.jsmod.skiphosts;
import java.util.regex.*;

public class DecoderLink
{

	public static boolean checkAll(String url)
	{
		/*
		if (checkAdf(url))
			return true;
			
		if (checkAhref(url))
			return true;
			
		*/
		return false;
	}

	private static boolean checkAhref(String url)
	{
		Matcher m = Pattern.compile("^https?://ahref\\.co/.+$").matcher(url);
		if (m.find())
		{
			new ahref().execute(url);
			return true;
		}
		return false;
	}

	private static boolean checkAdf(String url)
	{
		Matcher m = Pattern.compile("^https?://(adf\\.ly|g\\.gs|q\\.gs|j\\.gs)/.+$").matcher(url);
		if (m.find())
		{
			new Adfly().execute(url);
			return true;
		}
		return false;
	}


}
