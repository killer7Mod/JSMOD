package com.wmods.jsmod.skiphosts;

import android.os.*;
import android.util.*;
import android.widget.*;
import java.util.regex.*;
import org.apache.http.impl.client.*;
import com.wmods.jsmod.*;
import android.text.*;
import com.wmods.jsmod.utils.*;

public class Adfly extends AsyncTask<String, Void, Void>
{

	private String URL;

	private String Error;

	private String Content;

	public Adfly()
	{
		this.URL = "";
		this.Content = null;
		this.Error = null;
	}

	@Override
	protected void onPreExecute()
	{
		ModUtils.showToast(LangUtils.getString("ADFP"));
	}

	@Override
	protected Void doInBackground(String... urls)
	{
		this.URL = urls[0];
		this.Content = (String)ClassUtils.callStaticMethod("com.wmods.modding.Utils","getStringURL",new Class[]{String.class,boolean.class},URL,false);
		if (TextUtils.isEmpty(this.Content))
			this.Error = "Error in ADF.LY";
		return null;
	}

	@Override
	protected void onPostExecute(Void result)
	{
		int D;
		if (this.Error != null)
		{
			ModUtils.showToast("ADFLY: " + Error);
			ModUtils.openURL(URL,true);
			return;
		}
		String A = "";
		String T = "";
		String ysmm = "";

		try
		{
			Pattern regex = Pattern.compile("var ysmm \\= '(.*?)';");
			Matcher m = regex.matcher(this.Content);
			if (m.find())
			{
				ysmm = m.group(1);
				for (D = 0; D < ysmm.length(); D++)
				{
					if (D % 2 == 0)
					{
						A = A + ysmm.charAt(D);
					}
					else
					{
						T = ysmm.charAt(D) + T;
					}
				}
				String tmp = new String(Base64.decode(A + T, Base64.DEFAULT));
				if (!TextUtils.isEmpty(tmp) && tmp.length() > 2)
					ysmm = replaceAmazon(tmp.substring(2));
			}
			checkURLAndGo(ysmm);
		}
		catch (Throwable e)
		{
			checkURLAndGo(null);
		}
	}

    String replaceAmazon(String f)
	{
        if (f.contains("amazon") && f.contains("/gp/"))
		{
            String replacement;
            if (f.contains("t="))
			{
                String firstDelim = "t=";
                int p1 = f.indexOf(firstDelim);
                int p2 = f.indexOf("&");
                replacement = "appredirect-21";
                if (p1 >= 0 && p2 > p1)
				{
                    f = f.substring(0, firstDelim.length() + p1) + replacement;
                }
            }
			else if (f.contains("?"))
			{
                f = f + "&t=appredirect-21";
            }
			else
			{
                f = f + "?t=appredirect-21";
            }
            if (f.contains("&tag="))
			{
                String firstDel = "&tag=";
                int p3 = f.indexOf(firstDel);
                int p4 = f.indexOf("&");
                replacement = "appredirect-21";
                if (p3 >= 0 && p4 > p3)
				{
                    f = f.substring(0, firstDel.length() + p3) + replacement + f.substring(p4);
                }
            }
			else
			{
                f = f + "&tag=appredirect-21";
            }
        }
        return f;
    }

	private void checkURLAndGo(String url)
	{
		if (TextUtils.isEmpty(url))
		{
			ModUtils.showToast(LangUtils.getString("ADFE"));
			ModUtils.openURL(URL,true);
			return;
		}
		if (url.contains("/go.php?u="))
		{
			int p = url.indexOf("=") + 1;
			url = new String(Base64.decode(URL.substring(p), Base64.DEFAULT));
		}
		else if (url.contains("/redirecting/"))
		{
			int p = url.indexOf("/redirecting/") + 13;
			url = new String(Base64.decode(URL.substring(p), Base64.DEFAULT));
		}
		ModUtils.openURL(url,false);
	}
}
