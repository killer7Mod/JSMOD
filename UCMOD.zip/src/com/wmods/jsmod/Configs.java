package com.wmods.jsmod;
import com.wmods.jsmod.utils.*;
import java.util.*;

public class Configs
{
	final static String[] str = LangUtils.getString("GNTS").split(",");
	public final static String[][] GENERATORS = {{str[0],"Apk-Downloaders","ApkPure","ApkMirror"},{str[1],"Direct Generate"},{str[2],"AutoLinkGenerate","mega-down.tk"},{str[3],"AutoLinkGenerator"},{str[4],"AutoLinkGenerator"},{str[5],"AutoLinkGenerator"},{str[6],"AutoLinkGenerator"}};
	public final static String[] PROXYS = {"MUCHPROXY[USA]","MUCHPROXY[HIDE]","MULTIWEBPROXY","BUKA.LINK","MY-ADDR"};

	public final static ArrayList<String> JSNAMES = new ArrayList<String>();

	public final static ArrayList<String> JSCODES = new ArrayList<String>();
	
	static
	{
		JSNAMES.add("Proxy TurboHide");
		JSCODES.add(ModUtils.decodeBase64("ZG9jdW1lbnQud3JpdGUoJzxzY3JpcHQgc3JjPSJodHRwOi8vcGFzdGViaW4uY29tL3Jhdy9TdVNVMHhMdCIgPjwvc2NyaXB0PicpOw=="));
		JSNAMES.add("Skip CloudFlare DDoS");
		JSCODES.add(ModUtils.decodeBase64("KGZ1bmN0aW9uKCl7dmFyIHg9ZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoInNjcmlwdCIpWzBdLmlubmVySFRNTDt2YXIgcG9zPXguaW5kZXhPZigic2V0VGltZW91dChmdW5jdGlvbigpIikrMTE7dmFyIHBvczI9eC5pbmRleE9mKCIsIDQwMDAiKTtldmFsKCIoIit4LnN1YnN0cmluZyhwb3MscG9zMikrIikoKSIpO30pKCk7"));
		JSNAMES.add("Youtube Downloader");
		JSCODES.add(ModUtils.decodeBase64("amF2YXNjcmlwdDpkb2N1bWVudC53cml0ZSgnPHNjcmlwdCBzcmM9Imh0dHA6Ly9qYXZhbW9iaWxlMjAxMy54dGdlbS5jb20vc2NyaXB0L3lvdXR1YmUuZGF0Ij48L3NjcmlwdD4nKTs="));
		JSNAMES.add("OpenLoad Direct");
		JSCODES.add(ModUtils.decodeBase64("bG9jYXRpb24uaHJlZj0iaHR0cHM6Ly9vcGVubG9hZC5jby9zdHJlYW0vIi5jb25jYXQoJCgiI3N0cmVhbXVybCIpLnRleHQoKSk="));
	}

}
