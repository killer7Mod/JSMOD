package com.wmods.jsmod;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import com.wmods.jsmod.generators.*;
import com.wmods.jsmod.ui.*;
import com.wmods.jsmod.utils.*;
import java.util.*;

import static com.wmods.jsmod.utils.ModUtils.getActivity;
import static com.wmods.jsmod.utils.ModUtils.getContext;
import com.wmods.jsmod.skiphosts.*;
import android.os.*;
import android.app.*;
import android.text.*;

public class JSMOD
{

	Layouts mLayout = new Layouts();

	String URLDirect;

	boolean ButtonsAdded;

	public JSMOD()
	{
		mLayout = new Layouts();

	}

	// Hook URL
	// Parameter @{String=url} = "open url"
	// Parameter @{return=boolean} = "Not open page if true"
	public boolean hook_url(String url)
	{

		if (!ModUtils.isURL(url))
			return false;

		URLControl mURL = new URLControl(url);

		if ("command".equalsIgnoreCase(mURL.getHost()))
		{
			ModUtils.openURL(url.replace("cloud_dl_notice", "download"), true);
			return true;
		}

		if (Links.checkAll(url))
		{
			return true;
		}

		if (DecoderLink.checkAll(url))
		{
			return true;
		}

		return false;
	}

	public boolean hook_finish_load(Object gr)
	{
		String url = (String)ClassUtils.callMethod(gr, "getUrl", null);

		if (!ModUtils.isURL(url) || url.equals(URLDirect))
		{
			URLDirect = null;
			return false;
		}

		URLControl mUrl = new URLControl(url);

		if ("linkshrink.net".equalsIgnoreCase(mUrl.getHost()))
		{
			ModUtils.showToast("injetando javascript...");
			URLDirect = url;
			ModUtils.executeJavascript("$(\"#skip\").show()");
		}
		return false;
	}

	public void hook_updated()
	{

		HandlerThread ht = new HandlerThread("update");
		ht.start();
		new Handler(ht.getLooper()).post(
			new Runnable(){

				@Override
				public void run()
				{
					try
					{
						Thread.sleep(5000);
					}
					catch (InterruptedException e)
					{}

					String text = ModUtils.readFile(getActivity().getFilesDir().getAbsolutePath() + "/script/ChangeLog.txt");
					if (!TextUtils.isEmpty(text))
					{
						UCDialog dialog = new UCDialog(getActivity());
						dialog.setMessage(text.split("\\|")[1]);
						dialog.setTitle("JSMOD Update");
						dialog.setNegativeButton("OK", null);
						dialog.show();
					}
					Object pInstance = ClassUtils.callStaticMethod("com.uc.browser.p", "f", null);
					Object menu = ClassUtils.getObjectField(pInstance, "y");

					if (menu != null)
					{
						Object newMenu = ClassUtils.newInstance("com.uc.browser.cm", new Class[]{Context.class}, ModUtils.getActivity());
						ClassUtils.setObjectField(pInstance, "y", newMenu);
					}
					
				}

			});
	}


	public boolean hook_proxy(String[] param)
	{
		switch (PrefSave.PROXY_POSITION)
		{
			case 0:
				param[0] = "http://us.muchproxy.com/browse.php?b=2&u=" + java.net.URLEncoder.encode(param[0]);
				param[1] = "http://us.muchproxy.com/" + (param[1] != null ? "browse.php?u=" + java.net.URLEncoder.encode(param[1]) : "");
				break;
			case 1:
				param[0] = "http://hide.muchproxy.com/browse.php?b=2&u=" + java.net.URLEncoder.encode(param[0]);
				param[1] = "http://hide.muchproxy.com/" + (param[1] != null ? "browse.php?u=" + java.net.URLEncoder.encode(param[1]) : "");
				break;
			case 2:
				param[0] = "http://multiwebproxy.com/browse.php?b=2&u=" + java.net.URLEncoder.encode(param[0]);
				param[1] = "http://multiwebproxy.com/" + (param[1] != null ? "browse.php?u=" + java.net.URLEncoder.encode(param[1]) : "");
				break;
			case 3:
				param[0] = "http://buka.link/browse.php?b=2&u=" + java.net.URLEncoder.encode(param[0]);
				param[1] = "http://buka.link/" + (param[1] != null ? "browse.php?u=" + java.net.URLEncoder.encode(param[1]) : "");
				break;
			case 4:
				param[0] = "http://proxy9747.my-addr.org/myaddrproxy.php/" + (param[0].startsWith("https") ? "https" : "http") + "/" + param[0].replaceFirst("https?://", "");
				break;
			default:
				return false;
		}
		return true;
	}




	public void hook_page(Object o)
	{
		if (!ButtonsAdded)
		{
			ModUtils.addFloatButton("View Source", "g", 0xf001);
			ModUtils.addFloatButton("Javascript Injector", "g", 0xf002);
			ModUtils.addFloatButton("Open With", "f", 0xf003);
			ModUtils.addFloatButton("Open With", "e", 0xf003);
			ButtonsAdded = true;
		}
	}


	// Options on Long Click(Listener)
    // Parameter @{Object=o} = "Class com.uc.browser.o"
    // Parameter @{int=id} = "id of Option"
	public void hook_options_button(Object obj, int id)
	{
		switch (id)
		{
			case 0xf001:
				ModUtils.executeJavascript("location.href=\"View-Source:\".concat(location.href)");
				break;
			case 0xf002:
				Layouts.showJSInjector();
				break;
			case 0xf003:
				Intent intent = new Intent(Intent.ACTION_VIEW);
				Object web = ClassUtils.callMethod(obj, "Y", null);
				String url = (String)ClassUtils.callMethod(web, "ag", null);
				if (url == null)
					url = (String)ClassUtils.getObjectField(obj, "S");
				ModUtils.showToast(url);
				intent.setData(Uri.parse(url));
				getActivity().startActivity(Intent.createChooser(intent, "URL"));
				break;
		}
	}


	public void hook_menu_new(Object cw, ArrayList<Object> al)
	{
		//JS Menu
		al.add(ModUtils.new_menu_option(0xf004, 0xf003, 0xf104));
		//al.add(ModUtils.new_menu_option(0xf005, 0xf004, 0xf104));
	}

	// Menu Options(Name)
	// Parameter @{int=id_name} = "name_id"
	// Parameter @{ArrayList=al} = "add String for Id"
	public void hook_menu_name(int id_name, ArrayList<String> al)
	{
		switch (id_name)
		{
			case 0xf003:
				al.add("JS MOD");
				break;
			case 0xf004:
				al.add("TESTE");
				break;
		}
	}

	// Menu Options(Drawable)
	// Parameter @{int=id} = "drawable_id"
	// Parameter @{ArrayList=al} = "add Drawable for Id"
	public void hook_menu_draw(int id, ArrayList<Drawable> al)
	{
		switch (id)
		{
			case 0xf104:
				//al.add(Utils.getDraw(/*getContext().getFilesDir().getAbsolutePath() + */"/sdcard/download/script/jsmod.png"));
				al.add(new BitmapDrawable(BitmapFactory.decodeByteArray(Common.icon, 0, Common.icon.length)));
				break;
		}
	}

	// Menu Options(Id)
    // Parameter @{int=id} = "id"
	public void hook_menu_check(int id)
	{
		switch (id)
		{
			case 0xf004:
				mLayout.showJSMOD();
				break;
			case 0xf005:
				showWebView();
		}
	}

	private void showWebView()
	{
		hook_updated();
	}

}
