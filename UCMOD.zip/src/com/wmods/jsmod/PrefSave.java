package com.wmods.jsmod;
import android.content.*;
import java.util.*;
import android.content.SharedPreferences.*;
import android.util.*;
import java.util.Map.*;
import org.json.*;
import com.wmods.jsmod.utils.*;

public class PrefSave
{
	public static int PROXY_POSITION;

	public static boolean[] GENERATORS_ACTIVE;

	public static int[] GENERATORS_TYPE;

	public static HashMap<String,String> SCRIPTS = new HashMap<String,String>();

	static
	{
		SharedPreferences prefs = ModUtils.getContext().getSharedPreferences("JSMOD", Context.MODE_WORLD_READABLE);
		PROXY_POSITION = prefs.getInt("PPROXY", 0);
		String gActive = prefs.getString("GENERATORS_ACTIVE", null);
		String gType = prefs.getString("GENERATORS_TYPE", null);
		if (gActive != null && gType != null)
		{
			try
			{
				JSONArray gActive_json = new JSONArray(gActive);
				JSONArray gType_json = new JSONArray(gType);
				GENERATORS_ACTIVE = new boolean[gActive_json.length()];
				GENERATORS_TYPE = new int[gType_json.length()];
				for (int i = 0; i < GENERATORS_ACTIVE.length;i++)
				{
					GENERATORS_ACTIVE[i] = gActive_json.getBoolean(i);
					GENERATORS_TYPE[i] = gType_json.getInt(i);
				}

			}
			catch (Exception e)
			{}
		}

		String scripts = prefs.getString("SCRIPTS", null);
		if (scripts != null)
		{
			try
			{
				JSONObject scripts_json = new JSONObject(scripts);
				SCRIPTS = ModUtils.jsonToMap(scripts_json);
			}
			catch (Throwable e)
			{}
		}

	}

	public static void savePrefs()
	{
		SharedPreferences prefs = ModUtils.getContext().getSharedPreferences("JSMOD", Context.MODE_WORLD_WRITEABLE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putInt("PPROXY", PROXY_POSITION).commit();

		if (GENERATORS_ACTIVE != null)
		{
			JSONArray gActive_json = new JSONArray();
			JSONArray gType_json = new JSONArray();
			for (int i = 0;i < GENERATORS_ACTIVE.length;i++)
			{
				gActive_json.put(GENERATORS_ACTIVE[i]);
				gType_json.put(GENERATORS_TYPE[i]);
			}
			editor.putString("GENERATORS_ACTIVE", gActive_json.toString()).commit();
			editor.putString("GENERATORS_TYPE", gType_json.toString()).commit();
		}
		if (!SCRIPTS.isEmpty())
		{
			JSONObject scripts_json = new JSONObject(SCRIPTS);
			editor.putString("SCRIPTS", scripts_json.toString()).commit();
		}
		editor.apply();
	}
}
