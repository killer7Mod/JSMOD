package com.wmods.jsmod.utils;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.json.*;
import android.webkit.*;
import java.net.*;
import android.os.*;
import android.text.*;
import android.util.*;
import java.util.concurrent.*;
import com.wmods.jsmod.*;

public class ModUtils
{

	public static void showToast(String toast)
	{
		ClassUtils.callStaticMethod("com.wmods.modding.Utils", "showToast", new Class[]{String.class, int.class}, toast, 1);
	}

	public static void showDialog(final String title, final String content)
	{
		getActivity().runOnUiThread(
			new Runnable(){

				@Override
				public void run()
				{
					UCDialog dialog = new UCDialog(getActivity());
					dialog.setTitle(title);
					dialog.setMessage(content);
					dialog.setNegativeButton("OK", null);
					dialog.show();
				}

			});
	}

	public static void openURL(String url, boolean direct)
	{
		if (direct)
			ClassUtils.callStaticMethod("com.wmods.activities.Action", "openURLDirect", new Class[]{String.class}, url);
		else
			ClassUtils.callStaticMethod("com.wmods.activities.Action", "openURL", new Class[]{String.class}, url);
	}

	public static String getStringURL(String url, boolean useProxy)
	{
		return (String)ClassUtils.callStaticMethod("com.wmods.modding.Utils", "getStringURL", new Class[]{String.class,boolean.class}, url, useProxy);
	}

	public static String getStringURLD(String url, boolean useProxy)
	{
		return (String)ClassUtils.callStaticMethod("com.wmods.modding.Utils", "getStringURLD", new Class[]{String.class,boolean.class}, url, useProxy);
	}

	public static Object new_menu_option(int id, int name_id, int image_id)
	{
		return ClassUtils.newInstance(ClassUtils.findClass("com.uc.browser.cy"), new Class[]{int.class,int.class,int.class}, id, name_id, image_id);
	}

	public static Activity getActivity()
	{
		try
		{

			Context mActivity = (Context)ClassUtils.callStaticMethod("com.uc.browser.ActivityBrowser", "a", null);
			if (mActivity != null && mActivity instanceof Activity)
				return (Activity)mActivity;
			mActivity = (Context)ClassUtils.getStaticObjectField(ClassUtils.findClass("com.wmods.activities.MainActivity"), "mContext");
			if (mActivity != null && mActivity instanceof Activity)
				return (Activity)mActivity;
		}
		catch (Exception e)
		{
			throw new RuntimeException("getActivity Error: " + e);
		}
		throw new RuntimeException("getActivity Error: Activity Not Found");
	}
	public static Context getContext()
	{
		Object mContext = ClassUtils.callStaticMethod("com.wmods.modding.Utils", "getContext", null);
		if (mContext != null)
			return (Context)mContext;
		throw new RuntimeException("getContexr Error: Context Not Found");
	}


	public static Drawable getDraw(String path)
	{
		try
		{
			return Drawable.createFromStream(new FileInputStream(path), new File(path).getName());
		}
		catch (Exception e)
		{
			return new ColorDrawable(Color.BLACK);
		}
	}

	public static int getConfigInt(String key)
	{
		return (int)ClassUtils.callStaticMethod("com.wmods.modding.ScriptJS", "getConfigInt", new Class[]{String.class}, key);
	}

	public static String getConfigString(String key)
	{
		return (String)ClassUtils.callStaticMethod("com.wmods.modding.ScriptJS", "getConfigString", new Class[]{String.class}, key);
	}

	public static boolean getConfigBoolean(String key)
	{
		return (boolean)ClassUtils.callStaticMethod("com.wmods.modding.ScriptJS", "getConfigBoolean", new Class[]{String.class}, key);
	}

	public static HashMap<String, String> jsonToMap(JSONObject json) throws JSONException
	{
		HashMap<String, String> retMap = new HashMap<String, String>();

		if (json != JSONObject.NULL)
		{
			retMap = toMap(json);
		}
		return retMap;
	}

	private static HashMap<String, String> toMap(JSONObject object) throws JSONException
	{
		HashMap<String, String> map = new HashMap<String, String>();

		Iterator<String> keysItr = object.keys();
		while (keysItr.hasNext())
		{
			String key = keysItr.next();
			Object value = object.get(key);

			if (value instanceof JSONArray)
			{
				value = ((JSONArray) value).get(0);
			}
			map.put(key, (String)value);
		}
		return map;
	}

	public static void addFloatButton(String name, String f, int id)
	{
		Object array_obj = ClassUtils.getStaticObjectField(ClassUtils.findClass("adi"), f);
		int len = Array.getLength(array_obj);
		Object newArray = Array.newInstance(ClassUtils.findClass("adj"), len + 1);
		int i = 0;
		for (;i < len;i++)
		{
		    Object o = Array.get(array_obj, i);
			Array.set(newArray, i, o);
			if (ClassUtils.getIntField(o, "b") == id)
				return;
		}
		Array.set(newArray, i, ClassUtils.newInstance("adj", new Class[]{int.class,String.class}, id, name));
		ClassUtils.setStaticObjectField(ClassUtils.findClass("adi"), f, newArray);
	}

	public static boolean isURL(String url)
	{
		if (url == null)
			return false;
		try
		{
			new URL(url);
			return true;
		}
		catch (MalformedURLException e)
		{
			return false;
		}
	}

	public static String getNewLink(String url)
	{
		return (String)ClassUtils.callStaticMethod("com.wmods.activities.Action", "get", new Class[]{String.class}, url);
	}

	public static void allowNetworkOnThread()
	{
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
	}

	public static void saveFile(String filepath, byte[] data)
	{
		try
		{
			File f = new File(filepath);
			if (f.exists()) f.delete();
			f.createNewFile();
			FileOutputStream fos = new FileOutputStream(f);
			int pos = 0;
			while (pos < data.length)
			{
				int lenmax = Math.min(4096, data.length - pos);
				fos.write(data, pos, lenmax);
				pos += lenmax;
			}
			fos.close();
		}
		catch (Exception e)
		{
			ModUtils.showToast(e.toString());
		}
	}

	public static String readFile(String filePath)
	{
		try
		{
			File f = new File(filePath);
			if (f.exists() && f.canRead())
			{
				InputStream is = new FileInputStream(f);
				byte[] b = new byte[is.available()];
				is.read(b);
				return new String(b);
			}
		}
		catch (Exception e)
		{}
		return null;
	}

	public static void openURLDownload(String url, String referer, int fileSize)
	{
		StringBuffer sb = new StringBuffer("http://command/command=download?url=");
		sb.append(URLEncoder.encode(url));
		if (!TextUtils.isEmpty(referer))
		{
			sb.append("&referer=");
			sb.append(URLEncoder.encode(referer));
		}
		if (fileSize > 0)
		{
			sb.append("&fileSize=");
			sb.append(fileSize);
		}
		openURL(sb.toString(), true);
	}

	public static void showDownload(String url, String fileName, String referer, long fileSize)
	{
		String[] params = new String[11];
		params[0] = url;
		params[1] = referer;
		if (TextUtils.isEmpty(fileName))
		{
			fileName = URLUtil.guessFileName(url, null, null);
		}
		params[3] = fileName == null ? "unknow" : fileName;
		params[9] = String.valueOf(fileSize);
		ClassUtils.callStaticMethod("abk", "k", null);
		ClassUtils.callStaticMethod("abk", "a", new Class[]{String[].class,int.class,byte.class,int.class}, params, 0, (byte)0, 2);
	}

	public static void executeJavascript(String script)
	{
		StringBuffer sb = new StringBuffer("ext:es:javascript:");
		sb.append("eval(atob('");
		sb.append(Base64.encodeToString(script.getBytes(), 0));
		sb.append("'));");
		openURL(sb.toString(), false);
	}

	public static float pxToSp(float px)
	{
		float scaledDensity = getContext().getResources().getDisplayMetrics().scaledDensity;
		return px / scaledDensity;
	}

	public static float spToPx(float px)
	{
		float scaledDensity = getContext().getResources().getDisplayMetrics().scaledDensity;
		return px * scaledDensity;
	}

	public static int pxToDp(float px)
	{
		float dp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, px, getContext().getResources().getDisplayMetrics());
		return (int)dp;
	}

	public static int dpToPx(float dp)
	{
		float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getContext().getResources().getDisplayMetrics());
		return (int) px;
	}

	public static String decodeBase64(String data)
	{
		return new String(Base64.encode(data.getBytes(), Base64.DEFAULT));
	}
}
