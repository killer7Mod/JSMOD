package com.wmods.jsmod.utils;

import java.lang.reflect.*;
import java.util.*;
import org.json.*;

public class ClassUtils
{
	private static final HashMap<String, Field> fieldCache = new HashMap<String, Field>();

	public static class ClassNotFoundError extends Error
	{
		private static final long serialVersionUID = -1070936889459514628L;
		public ClassNotFoundError(Throwable cause)
		{
			super(cause);
		}
		public ClassNotFoundError(String detailMessage, Throwable cause)
		{
			super(detailMessage, cause);
		}
	}

	public static Class<?> findClass(String name)
	{
		try
		{
			return Class.forName(name);
		}
		catch (Exception e)
		{}
		return null;
	}

	public static Object newInstance(Class<?> cls, Class[] parameters, Object... args)
	{
		try
		{
			Constructor<?> contructor = cls.getDeclaredConstructor(parameters);
			contructor.setAccessible(true);
			return contructor.newInstance(args);
		}
		catch (Exception e)
		{
			throw new ClassNotFoundError(e);
		}
	}

	public static Object newInstance(String className, Class[] parameters, Object... args)
	{
		try
		{
			return newInstance(Class.forName(className), parameters, args);
		}
		catch (ClassNotFoundException e)
		{
			throw new ClassNotFoundError(e);
		}
	}

	public static Object newInstance(String className, Object... args)
	{
		try
		{
			return newInstance(Class.forName(className), getParameterTypes(args), args);
		}
		catch (ClassNotFoundException e)
		{
			throw new ClassNotFoundError(e);
		}
	}


	public static Object callMethod(Object thiz, String methodName, Class[] cls, Object... obj)
	{
		try
		{
			Class<?> cl = thiz.getClass();
			Method method;
			try
			{
				method = cl.getDeclaredMethod(methodName, cls);
			}
			catch (Exception e)
			{
				method = cl.getSuperclass().getDeclaredMethod(methodName,cls);
			}
			method.setAccessible(true);
			return method.invoke(thiz, obj);
		}
		catch (Exception e)
		{
			throw new ClassNotFoundError(e);
		}
	}

	public static Object callStaticMethod(String className, String method, Class[] cls, Object... obj)
	{
		try
		{
			Class<?> cl = Class.forName(className);
			Method m = cl.getDeclaredMethod(method, cls);
			m.setAccessible(true);
			return m.invoke(null, obj);
		}
		catch (Exception e)
		{
			throw new ClassNotFoundError(e);
		}
	}


	public static Class<?>[] getParameterTypes(Object... args)
	{
		Class<?>[] clazzes = new Class<?>[args.length];
		for (int i = 0; i < args.length; i++)
		{
			clazzes[i] = (args[i] != null) ? args[i].getClass() : null;
		}
		return clazzes;
	}

	private static Class<?>[] getParameterClasses(Object[] parameterTypesAndCallback)
	{
		Class<?>[] parameterClasses = null;
		for (int i = parameterTypesAndCallback.length - 1; i >= 0; i--)
		{
			Object type = parameterTypesAndCallback[i];
			if (type == null)
				throw new ClassNotFoundError("parameter type must not be null", null);

			if (parameterClasses == null)
				parameterClasses = new Class<?>[i + 1];

			if (type instanceof Class)
				parameterClasses[i] = (Class<?>) type;
			else if (type instanceof String)
				parameterClasses[i] = findClass((String) type);
			else
				throw new ClassNotFoundError("parameter type must either be specified as Class or String", null);
		}
		// if there are no arguments for the method
		if (parameterClasses == null)
			parameterClasses = new Class<?>[0];

		return parameterClasses;
	}

	public static Class<?>[] getClassesAsArray(Class<?>... clazzes)
	{
		return clazzes;
	}

	public static Field findField(Class<?> clazz, String fieldName)
	{
		StringBuilder sb = new StringBuilder(clazz.getName());
		sb.append('#');
		sb.append(fieldName);
		String fullFieldName = sb.toString();

		if (fieldCache.containsKey(fullFieldName))
		{
			Field field = fieldCache.get(fullFieldName);
			if (field == null)
				throw new NoSuchFieldError(fullFieldName);
			return field;
		}

		try
		{
			Field field = findFieldRecursiveImpl(clazz, fieldName);
			field.setAccessible(true);
			fieldCache.put(fullFieldName, field);
			return field;
		}
		catch (NoSuchFieldException e)
		{
			fieldCache.put(fullFieldName, null);
			throw new NoSuchFieldError(fullFieldName);
		}
	}

	private static Field findFieldRecursiveImpl(Class<?> clazz, String fieldName) throws NoSuchFieldException
	{
		try
		{
			return clazz.getDeclaredField(fieldName);
		}
		catch (NoSuchFieldException e)
		{
			while (true)
			{
				clazz = clazz.getSuperclass();
				if (clazz == null || clazz.equals(Object.class))
					break;

				try
				{
					return clazz.getDeclaredField(fieldName);
				}
				catch (NoSuchFieldException ignored)
				{}
			}
			throw e;
		}
	}

	public static void setObjectField(Object obj, String fieldName, Object value)
	{
		try
		{
			findField(obj.getClass(), fieldName).set(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setBooleanField(Object obj, String fieldName, boolean value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setBoolean(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setByteField(Object obj, String fieldName, byte value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setByte(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setCharField(Object obj, String fieldName, char value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setChar(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setDoubleField(Object obj, String fieldName, double value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setDouble(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setFloatField(Object obj, String fieldName, float value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setFloat(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setIntField(Object obj, String fieldName, int value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setInt(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setLongField(Object obj, String fieldName, long value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setLong(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setShortField(Object obj, String fieldName, short value)
	{
		try
		{
			findField(obj.getClass(), fieldName).setShort(obj, value);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	//#################################################################################################
	public static Object getObjectField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).get(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	/** For inner classes, return the "this" reference of the surrounding class */
	public static Object getSurroundingThis(Object obj)
	{
		return getObjectField(obj, "this$0");
	}

	public static boolean getBooleanField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getBoolean(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static byte getByteField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getByte(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static char getCharField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getChar(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static double getDoubleField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getDouble(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static float getFloatField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getFloat(obj);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static int getIntField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getInt(obj);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static long getLongField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getLong(obj);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static short getShortField(Object obj, String fieldName)
	{
		try
		{
			return findField(obj.getClass(), fieldName).getShort(obj);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	//#################################################################################################
	public static void setStaticObjectField(Class<?> clazz, String fieldName, Object value)
	{
		try
		{
			findField(clazz, fieldName).set(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticBooleanField(Class<?> clazz, String fieldName, boolean value)
	{
		try
		{
			findField(clazz, fieldName).setBoolean(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticByteField(Class<?> clazz, String fieldName, byte value)
	{
		try
		{
			findField(clazz, fieldName).setByte(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticCharField(Class<?> clazz, String fieldName, char value)
	{
		try
		{
			findField(clazz, fieldName).setChar(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticDoubleField(Class<?> clazz, String fieldName, double value)
	{
		try
		{
			findField(clazz, fieldName).setDouble(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticFloatField(Class<?> clazz, String fieldName, float value)
	{
		try
		{
			findField(clazz, fieldName).setFloat(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticIntField(Class<?> clazz, String fieldName, int value)
	{
		try
		{
			findField(clazz, fieldName).setInt(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticLongField(Class<?> clazz, String fieldName, long value)
	{
		try
		{
			findField(clazz, fieldName).setLong(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static void setStaticShortField(Class<?> clazz, String fieldName, short value)
	{
		try
		{
			findField(clazz, fieldName).setShort(null, value);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	//#################################################################################################
	public static Object getStaticObjectField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).get(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static boolean getStaticBooleanField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getBoolean(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static byte getStaticByteField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getByte(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static char getStaticCharField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getChar(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static double getStaticDoubleField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getDouble(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static float getStaticFloatField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getFloat(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static int getStaticIntField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getInt(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static long getStaticLongField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getLong(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

	public static short getStaticShortField(Class<?> clazz, String fieldName)
	{
		try
		{
			return findField(clazz, fieldName).getShort(null);
		}
		catch (IllegalAccessException e)
		{
			// should not happen

			throw new IllegalAccessError(e.getMessage());
		}
		catch (IllegalArgumentException e)
		{
			throw e;
		}
	}

}
