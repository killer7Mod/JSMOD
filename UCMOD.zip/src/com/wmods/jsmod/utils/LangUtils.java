package com.wmods.jsmod.utils;
import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.util.*;

public class LangUtils
{

	private static HashMap<String, String> mStrings;

	static{
		loadXml();
	}
	
	public static void loadXml()
	{
		try
		{
			mStrings = new HashMap<String,String>();
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder doc = dbf.newDocumentBuilder();
			Document document = doc.parse(new File(ModUtils.getActivity().getFilesDir(),"script/strings-pt.xml"));
			NodeList strings = document.getElementsByTagName("string");
			for (int i=0;i < strings.getLength();i++)
			{
				Node node = strings.item(i);
				String key = node.getAttributes().item(0).getNodeValue();
				String value = node.getTextContent();
				mStrings.put(key, value);
			}
		}
		catch (Exception e)
		{}
	}
	
	
	public static String getString(String key){
		if (mStrings.containsKey(key))
			return mStrings.get(key);
		return "Not Found: "+key;
	}
	
}
