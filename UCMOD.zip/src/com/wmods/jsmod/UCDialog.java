package com.wmods.jsmod;

import android.content.*;
import java.lang.reflect.*;
import android.view.*;
import android.app.*;
import com.wmods.jsmod.utils.*;

public class UCDialog
{
	Object mDialog;

	public UCDialog(Context ctx)
	{
		mDialog = ClassUtils.newInstance("agd", new Class[]{Context.class}, ctx);
	}

	public void dismiss()
	{
		ClassUtils.callMethod(mDialog, "dismiss", null);
	}

	public void setTitle(String title)
	{
		ClassUtils.callMethod(mDialog, "setTitle", new Class[]{CharSequence.class}, title);
	}

	public void setItems(String[] items, DialogInterface.OnClickListener onClick)
	{
		ClassUtils.callMethod(mDialog, "a", new Class[]{CharSequence[].class,DialogInterface.OnClickListener.class}, items, onClick);
	}

	public void setMessage(String content)
	{
		ClassUtils.callMethod(mDialog, "a", new Class[]{CharSequence.class}, content);
	}

	public void setView(View view)
	{
		ClassUtils.callMethod(mDialog, "a", new Class[]{View.class}, view);
	}

	public void setNeutralButton(String name, DialogInterface.OnClickListener onClick)
	{
		try
		{
			mDialog.getClass().getMethod("b", CharSequence.class, DialogInterface.OnClickListener.class).invoke(mDialog, name, onClick);
		}
		catch (Exception e)
		{}

	}

	public void setNegativeButton(String name, DialogInterface.OnClickListener onClick)
	{
		try
		{
			mDialog.getClass().getMethod("a", CharSequence.class, DialogInterface.OnClickListener.class).invoke(mDialog, name, onClick);
		}
		catch (Exception e)
		{}

	}

	public void setPositiveButton(String name, DialogInterface.OnClickListener onClick)
	{
		try
		{
			mDialog.getClass().getMethod("c", CharSequence.class, DialogInterface.OnClickListener.class).invoke(mDialog, name, onClick);
		}
		catch (Exception e)
		{}

	}

	public void show()
	{
		try
		{
			mDialog.getClass().getMethod("show").invoke(mDialog);
		}
		catch (Exception e)
		{}
	}

}
