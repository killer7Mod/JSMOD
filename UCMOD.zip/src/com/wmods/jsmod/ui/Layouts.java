package com.wmods.jsmod.ui;

import android.content.*;
import android.graphics.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;
import android.widget.CompoundButton.*;
import android.widget.LinearLayout.*;
import com.wmods.jsmod.*;
import com.wmods.jsmod.utils.*;
import java.util.*;

import android.widget.LinearLayout.LayoutParams;

import static com.wmods.jsmod.utils.ModUtils.getActivity;

public class Layouts implements 
View.OnClickListener,OnCheckedChangeListener,OnItemSelectedListener
{

	private Button gButton;

	private Button jButton;

	private Button pButton;

	//Generators
	private boolean[] generatorsActive;
	private int[] generatorsType;

	// Javascripts
	private HashMap<String,String> SCRIPTS_TMP;
	private DialogInterface.OnClickListener cancelInterface = new DialogInterface.OnClickListener(){

		@Override
		public void onClick(DialogInterface p1, int p2)
		{
			p1.dismiss();
			showJavascript();
		}
	};

	public static void showJSInjector()
	{
		getActivity().
			runOnUiThread(
			new Runnable(){

				@Override
				public void run()
				{
					UCDialog dialog = new UCDialog(getActivity());
					dialog.setTitle("Javascript");
					if (PrefSave.SCRIPTS.isEmpty())
					{
						ModUtils.showToast(LangUtils.getString("EMPTY_SCRIPT"));
						return;
					}
					Set<String> keys = PrefSave.SCRIPTS.keySet();
					final String[] arr = keys.toArray(new String[keys.size()]);

					ArrayList<String> al = (ArrayList<String>)Configs.JSNAMES.clone();
					Collections.addAll(al, arr);

					String[] arr2 = al.toArray(new String[0]); 

					dialog.setItems(arr2,
						new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								int size = Configs.JSNAMES.size();
								if (p2 < size)
								{
									ModUtils.executeJavascript(Configs.JSCODES.get(p2));
								}
								else
								{
									ModUtils.executeJavascript(PrefSave.SCRIPTS.get(arr[p2 - size]));
								}
								p1.dismiss();
							}

						});
					dialog.setNegativeButton("EXIT", null);
					dialog.show();
				}
			});
	}


	@Override
	public void onClick(View p1)
	{
		if (p1.equals(gButton))
		{
			showGenerators();
		}
		else if (p1.equals(jButton))
		{
			showJavascript();
		}
		else if (p1.equals(pButton))
		{
			showCustomProxy();
		}

	}

	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		if (p1.getTag() != null)
		{
			generatorsActive[Integer.parseInt((String)p1.getTag())] = p2;
		}
	}

	@Override
	public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
	{
		if (p1.getTag() != null)
		{
			generatorsType[Integer.parseInt((String)p1.getTag())] = p3;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> p1)
	{
		// TODO: Implement this method
	}


	private void showCustomProxy()
	{
		UCDialog dialog = new UCDialog(getActivity());
		dialog.setTitle(LangUtils.getString("PCUSTOM"));
		String[] proxys = Configs.PROXYS;
		LinearLayout mainLayout = new LinearLayout(getActivity());
		mainLayout.setOrientation(LinearLayout.VERTICAL);
		mainLayout.setBackgroundColor(Color.BLACK);
		List<String> list = Arrays.asList(proxys);
		ArrayAdapter adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, list);
		final Spinner spinner = new Spinner(getActivity());
		spinner.setAdapter(adapter);
		if (PrefSave.PROXY_POSITION <= proxys.length - 1)
			spinner.setSelection(PrefSave.PROXY_POSITION, false);
		mainLayout.addView(spinner);

		LinearLayout border = new LinearLayout(getActivity());
		border.setBackgroundColor(0xffdfdfdf);
		border.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
		TextView textView = new TextView(getActivity());
		textView.setBackgroundColor(0xff000000);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		params.setMargins(1, 1, 1, 1);
		textView.setLayoutParams(params);
		if (ModUtils.getConfigInt("PROXIES") == 8)
			textView.setText(Html.fromHtml("<font color=\"green\">O Custom Proxy está ativado<br>Use para fazer downloads e assistir video(nescessario ativar a função \"Proxy nas configurações\")</font></h5>"));
		else
			textView.setText(Html.fromHtml("<font color=\"red\">Atenção: O Custom Proxy está desativado<br>Vá em \"Menu Extra\" na seleção \"Proxy para Download\" selecione \"Custom\"</font>"));
		border.addView(textView);
		mainLayout.addView(border);

		dialog.setView(mainLayout);
		dialog.setNeutralButton(LangUtils.getString("SAVE"), new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
				    PrefSave.PROXY_POSITION = spinner.getSelectedItemPosition();
					PrefSave.savePrefs();
					p1.dismiss();
				}

			});
		dialog.setNegativeButton(LangUtils.getString("BACK"), null);
		dialog.show();
	}

	private void showJavascript()
	{
		final UCDialog dialog = new UCDialog(getActivity());
		dialog.setTitle("JAVASCRIPT INJECTOR");
		LinearLayout layout = new LinearLayout(getActivity());
		layout.setOrientation(LinearLayout.VERTICAL);
		layout.setBackgroundColor(0xff000000);

		TextView textview = new TextView(getActivity());
		textview.setText("SCRIPTS");

		ListView list = new ListView(getActivity());
		list.setScrollbarFadingEnabled(false);
		list.setOnItemLongClickListener(
			new OnItemLongClickListener(){

				@Override
				public boolean onItemLongClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					ArrayAdapter<String> arr = (ArrayAdapter<String>)p1.getAdapter();
					String item = arr.getItem(p3);
					arr.remove(item);
					arr.notifyDataSetChanged();
					SCRIPTS_TMP.remove(item);
					return true;
				}
			});

		list.setOnItemClickListener(
			new AdapterView.OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					ArrayAdapter<String> arr = (ArrayAdapter<String>)p1.getAdapter();
					String item = arr.getItem(p3);
					dialog.dismiss();
					showEditor(item);
				}

			});

		if (SCRIPTS_TMP == null)
		{
			SCRIPTS_TMP = new HashMap<String,String>(PrefSave.SCRIPTS);			
		}
		if (!SCRIPTS_TMP.isEmpty())
		{
			Set<String> keys = SCRIPTS_TMP.keySet();
			ArrayList<String> al = new ArrayList<String>();
			Collections.addAll(al, keys.toArray(new String[keys.size()]));
			list.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, al));
		}

		Button addbtn = new Button(getActivity());
		addbtn.setText(LangUtils.getString("ADD_SCRIPT"));
		addbtn.setOnClickListener(
			new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					dialog.dismiss();
					newJavascript();
				}
			});
		layout.addView(textview);
		layout.addView(list);
		layout.addView(addbtn);
		dialog.setView(layout);
		dialog.setNegativeButton(LangUtils.getString("CANCEL"),
			new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					SCRIPTS_TMP = null;
					p1.dismiss();
				}

			});
		dialog.setNeutralButton(LangUtils.getString("SAVE"),
			new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					PrefSave.SCRIPTS = SCRIPTS_TMP;
					PrefSave.savePrefs();
					p1.dismiss();
				}

			});


		dialog.show();
	}

	private void newJavascript()
	{
		UCDialog dialog = new UCDialog(getActivity());
		dialog.setTitle(LangUtils.getString("ADD_SCRIPT"));
		LinearLayout layoutOptions = new LinearLayout(getActivity());
		layoutOptions.setBackgroundColor(0xff000000);
		layoutOptions.setOrientation(LinearLayout.VERTICAL);
	    LinearLayout.LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		int margin = ModUtils.dpToPx(10);
		params.setMargins(0, margin, 0, 0);
		TextView t1 = new TextView(getActivity());
		t1.setText(LangUtils.getString("NAME"));
		final EditText et1 = new EditText(getActivity());
		//et1.addTextChangedListener(textwatcher);
		TextView t2 = new TextView(getActivity());
		t2.setText(LangUtils.getString("CODE"));
		final EditText et2 = new EditText(getActivity());
		et2.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 150));//dpToPx(150)));
		et2.setGravity(Gravity.TOP);
		layoutOptions.addView(t1);
		layoutOptions.addView(et1);
		layoutOptions.addView(t2);
		layoutOptions.addView(et2);
		dialog.setView(layoutOptions);

		dialog.setNeutralButton(LangUtils.getString("ADD"),
			new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					String text = et1.getText().toString();
					String text2 = et2.getText().toString();
					if (text.trim().length() == 0 || text2.trim().length() == 0)
					{
						ModUtils.showToast(LangUtils.getString("EMPTY_FIELD"));
						return;
					}
					SCRIPTS_TMP.put(text, text2);
					showJavascript();
					p1.dismiss();
				}


			});
		dialog.setNegativeButton(LangUtils.getString("CANCEL"), cancelInterface);
		dialog.show();
	}

	private void showEditor(final String name)
	{
		UCDialog dialog = new UCDialog(getActivity());
		dialog.setTitle(LangUtils.getString("JS"));
		LinearLayout layout = new LinearLayout(getActivity());
		layout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		layout.setOrientation(1);
		layout.setBackgroundColor(android.graphics.Color.BLACK);
		TextView t = new TextView(getActivity());
		t.setText(LangUtils.getString("NAME") + ":" + name);
		final EditText et = new EditText(getActivity());
		et.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, ModUtils.dpToPx(200)));
		et.setGravity(Gravity.TOP);
	    et.setText(SCRIPTS_TMP.get(name));
		//et.addTextChangedListener(textwatcher);
		layout.addView(t);
		layout.addView(et);
		dialog.setView(layout);
		dialog.setNeutralButton(LangUtils.getString("SAVE"),
			new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface dialog, int p2)
				{
					String text = et.getText().toString();
					if (text.trim().length() == 0)
					{
						ModUtils.showToast(LangUtils.getString("EMPTY_FIELD"));
						return;
					}
					SCRIPTS_TMP.remove(name);
					SCRIPTS_TMP.put(name, text);
					dialog.dismiss();
					showJavascript();
				}


			});
		dialog.setNegativeButton(LangUtils.getString("CANCEL"), cancelInterface);
		dialog.show();
	}

	private void showGenerators()
	{
		UCDialog alert = new UCDialog(getActivity());
		alert.setTitle(LangUtils.getString("GNT"));
		String[][] generators = Configs.GENERATORS;
		LinearLayout mainLayout = new LinearLayout(getActivity());
		mainLayout.setOrientation(LinearLayout.VERTICAL);
		mainLayout.setBackgroundColor(Color.BLACK);
		ScrollView scrollLayout = new ScrollView(getActivity());
		LinearLayout secondLayout = new LinearLayout(getActivity());
		secondLayout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
		generatorsActive = new boolean[generators.length];
		generatorsType = new int[generators.length];
		if (PrefSave.GENERATORS_ACTIVE != null)
		{
			System.arraycopy(PrefSave.GENERATORS_ACTIVE, 0, generatorsActive, 0, PrefSave.GENERATORS_ACTIVE.length);
			System.arraycopy(PrefSave.GENERATORS_TYPE, 0, generatorsType, 0, PrefSave.GENERATORS_TYPE.length);
		}

		for (int i = 0 ; i < generators.length; i++)
		{
			LinearLayout hlayout = new LinearLayout(getActivity());
			hlayout.setOrientation(LinearLayout.HORIZONTAL);
			CheckBox cb = new CheckBox(getActivity());
			cb.setLayoutParams(lp);
			cb.setText(generators[i][0]);
			cb.setTag(String.valueOf(i));
			cb.setChecked(generatorsActive[i]);
			cb.setOnCheckedChangeListener(this);
			hlayout.addView(cb);
			ArrayList<String> arraylist = new ArrayList<String>();
			Collections.addAll(arraylist, generators[i]);
			arraylist.remove(0);
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, arraylist);
			Spinner spinner = new Spinner(getActivity());
			spinner.setLayoutParams(lp);
			spinner.setAdapter(adapter);
			spinner.setTag(String.valueOf(i));
			if (generatorsType.length > i)
				spinner.setSelection(generatorsType[i], false);
			spinner.setOnItemSelectedListener(this);
			hlayout.addView(spinner);
			secondLayout.addView(hlayout);
		}
		scrollLayout.addView(secondLayout);
		mainLayout.addView(scrollLayout);
		alert.setView(mainLayout);
		alert.setNegativeButton(LangUtils.getString("BACK"), null);
		alert.setNeutralButton(LangUtils.getString("SAVE"), new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					PrefSave.GENERATORS_ACTIVE = generatorsActive;
					PrefSave.GENERATORS_TYPE = generatorsType;
					PrefSave.savePrefs();
					p1.dismiss();
				}


			});
		alert.show();
	}

	public void showJSMOD()
	{
		getActivity().runOnUiThread(
			new Runnable(){

				private Button adsbutton;
				@Override
				public void run()
				{
					UCDialog painel = new UCDialog(getActivity());
					LinearLayout main_layout = new LinearLayout(getActivity());
					main_layout.setOrientation(LinearLayout.VERTICAL);
					gButton = new Button(getActivity());
					gButton.setText(LangUtils.getString("GNT"));
					gButton.setOnClickListener(Layouts.this);
					jButton = new Button(getActivity());
					jButton.setText(LangUtils.getString("JS"));
					jButton.setOnClickListener(Layouts.this);
					pButton = new Button(getActivity());
					pButton.setText(LangUtils.getString("PCUSTOM"));
					pButton.setOnClickListener(Layouts.this);
					adsbutton = new Button(getActivity());
					adsbutton.setText("Desprotetores");
					main_layout.addView(gButton);
					main_layout.addView(jButton);
					main_layout.addView(pButton);
					main_layout.addView(adsbutton);
					painel.setView(main_layout);
					painel.setTitle(LangUtils.getString("JSMOD"));
					painel.setNegativeButton(LangUtils.getString("EXIT"), null);
					painel.show();
				}});
	}

}
