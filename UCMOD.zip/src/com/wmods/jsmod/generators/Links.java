package com.wmods.jsmod.generators;
import com.wmods.jsmod.*;
import java.net.*;
import java.util.regex.*;
import com.wmods.jsmod.utils.*;

public class Links
{

	public static boolean checkAll(String url)
	{
		Pattern p = Pattern.compile("https?://(?:www\\.|m\\.)?google\\.com(?:\\.br)?/url\\?q=([^&]+)", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(url);

		if (m.find() && ModUtils.isURL(m.group(1)))
		{
			url = URLDecoder.decode(m.group(1));
		}

		if (checkReverseURL(url))
			return true;

		if (checkGoogleDrive(url))
			return true;

		if (checkPlayStore(url))
			return true;

		if (checkMega(url))
			return true;
			
		if (checkMediafire(url))
			return true;

		return false;
	}


	private static boolean checkMediafire(String url)
	{
		Matcher m = Pattern.compile("https?://(www\\.)mediafire\\.com").matcher(url);
		if (m.find())
		{
			MediaFire.start(url);
			return true;
		}
		return false;
	}

	private static boolean checkMega(String url)
	{
		Pattern p = Pattern.compile("https?://(www\\.)?mega(\\.co)?\\.nz/#", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(url);
		if (m.find() && PrefSave.GENERATORS_ACTIVE[2])
		{
			switch (PrefSave.GENERATORS_TYPE[2])
			{
				case 0:
					new AutoLinkGenerate(url).start();
					break;
				case 1:
					ModUtils.openURL("http://mega-down.tk/?url=" + URLEncoder.encode(url), false);
					break;
			}
			return true;
		}

		return false;
	}


	private static boolean checkReverseURL(String url)
	{
		if (url.contains("//:ptth"))
		{
			int pos = url.lastIndexOf('=');
			if (pos != -1)
			{
				StringBuffer sb = new StringBuffer();
				sb.append(url, (pos + 1), (url.length() - (pos + 1)));
				ModUtils.showToast(LangUtils.getString("RLINK"));
				ModUtils.openURL(sb.reverse().toString(), false);
				return true;
			}
		}
		return false;
	}


	private static boolean checkPlayStore(String url)
	{
		Pattern p = Pattern.compile("https?://(?:www\\.)?play\\.google\\.com/store/apps/details\\?id=([\\w-\\.]+)", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(url);
		if (m.find() && PrefSave.GENERATORS_ACTIVE[0])
		{
			switch (PrefSave.GENERATORS_TYPE[0])
			{
				case 0:
					ModUtils.openURL("http://apk-downloaders.com/download/dl.php?dl=" + m.group(1), false);
					break;
				case 1:
					ModUtils.openURL("https://m.apkpure.com/search?q=" + m.group(1), false);
					break;
				case 2:
					ModUtils.openURL("http://www.apkmirror.com/?s=" + m.group(1) + "&post_type=app_release&searchtype=apk", false);

			}
			return true;
		}
		return false;
	}


	private static boolean checkGoogleDrive(String mUrl)
	{
		Pattern p = Pattern.compile("https?://(?:[\\w\\-]+\\.)*(?:drive|docs)\\.google\\.com/(?:(?:folderview|open|uc)\\?(?:[\\w\\-\\%]+=[\\w\\-\\%]*&)*id=|(?:folder|file|document|presentation|spreadsheets)/d/|spreadsheet/ccc\\?(?:[\\w\\-\\%]+=[\\w\\-\\%]*&)*key=|drive/folders/)([\\w\\-]{28,})", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(mUrl);
		if (m.find() && PrefSave.GENERATORS_ACTIVE[1])
		{
			switch (PrefSave.GENERATORS_TYPE[1])
			{
				case 0:
					ModUtils.showToast(LangUtils.getString("GNT_SUCESS"));
					ModUtils.openURLDownload("http://drive.google.com/uc?export=download&id=" + m.group(1), null, 0);
					break;
				case 1:
					//RapidLeech.start(mUrl.toString());
					break;
			}
			return true;
		}
		return false;
	}




}
