package com.wmods.jsmod.generators;

import com.wmods.jsmod.*;
import java.net.*;
import java.util.regex.*;
import android.text.*;
import com.wmods.jsmod.utils.*;

public class AutoLinkGenerate extends Thread
{

	private String mURL;

	public AutoLinkGenerate(String url)
	{
		this.mURL = url;
	}

	@Override
	public void run()
	{
		ModUtils.showToast(LangUtils.getString("GNT_PROGRESS"));
		String html = (String)ClassUtils.callStaticMethod("com.wmods.modding.Utils", "getStringURL", new Class[]{String.class,boolean.class}, "http://www.autogeneratelink.com/link.php?link=" + URLEncoder.encode(mURL) + "&token=agl", false);
		if (!TextUtils.isEmpty(html))
		{
			Pattern p = Pattern.compile("href='([^\\']+)'");
			Matcher matcher = p.matcher(html);
			if (matcher.find() && ModUtils.isURL(matcher.group(1)))
			{
				ModUtils.showToast(LangUtils.getString("GNT_SUCESS"));
				ModUtils.openURL(matcher.group(1), false);
				return;
			}
		}
		ModUtils.showToast(LangUtils.getString("GNT_FAILED"));
		ModUtils.openURL(mURL, true);
	}
	
}
