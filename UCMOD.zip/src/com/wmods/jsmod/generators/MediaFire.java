package com.wmods.jsmod.generators;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
import com.wmods.jsmod.utils.*;
import android.util.*;
import java.util.regex.*;
import java.net.*;

public class MediaFire implements Runnable
{
	private String mUrl;

	private MediaFire(String url)
	{
		this.mUrl = url;
	}

	public static void start(String url)
	{
		new Thread(new MediaFire(url)).start();
	}

	@Override
	public void run()
	{
		try
		{
			ModUtils.showToast("Gerando Link...");
			String content = (String)ClassUtils.callStaticMethod("com.wmods.modding.Utils", "getStringURL", new Class[]{String.class,boolean.class}, mUrl, true);
			Document doc = Jsoup.parse(content);
			Elements v = doc.getElementsByClass("download_link");
			Elements a = v.get(0).getElementsByTag("a");
			String link = a.get(0).attr("href");
			Matcher m = Pattern.compile("u=(.+?)&").matcher(link);
			if (m.find())
				ModUtils.showDownload(URLDecoder.decode(m.group(1)), null, null, 0);
			else
				ModUtils.showToast("Proxy nas Configuracoes está ativado?");
		}
		catch (Exception e)
		{
			ModUtils.showDialog("", Log.getStackTraceString(e));
		}
	}

}
