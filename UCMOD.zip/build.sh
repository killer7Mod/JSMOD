JSMOD2=/sdcard/linux/projetos/JSMOD
JSMOD=/sdcard/JSMOD

if [ -e ./build ]; then
rm -r ./build
fi

echo "copiando arquivos..."
cp ./bin/build/classes.dex ./build/JSMOD.dex
cp ./assets/* ./build

cd build

echo "compactando..."
zip UCMOD.zip -r ./*

cp -f UCMOD.zip $JSMOD2
cp -f ../UCMOD.ini $JSMOD2

cd $JSMOD2

version=$(cat UCMOD.ini | sed -E "s/Version=([0-9]+$)/\1/")

git add *
git commit -m "update to version $version"
git push origin master
